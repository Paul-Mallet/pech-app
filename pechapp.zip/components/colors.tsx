const Colors = {
    textDark: '#003B44',
    textHighlightDark: '#31909C',
    textBoldLight: '#F6FEFF',
    backgroundLight: '#FFFDF6'
};
  
export default Colors;